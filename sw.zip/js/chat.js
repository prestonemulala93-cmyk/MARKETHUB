import { state, findItem } from './state.js';
import { escapeHtml, toast } from './utils.js';
import { getClient } from './auth.js';

const KEY = 'mh_chats';

function loadChats() {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
}
function saveChats(rows) {
  localStorage.setItem(KEY, JSON.stringify(rows.slice(-400)));
}

function threadId(listingId, buyerId) {
  return `${listingId || 'item'}:${buyerId || 'guest'}`;
}

export function openChatForItem(id) {
  const x = findItem(id);
  if (!x) return;
  if (!state.session?.user) {
    window.marketHubAuth?.open();
    toast('Sign in to chat with the seller.');
    return;
  }
  state.chatListingId = id;
  document.getElementById('chatTitle').textContent = `Chat · ${x.title}`;
  document.getElementById('chatSub').textContent = `Seller: ${x.seller}`;
  renderThread();
  document.getElementById('chatModal').classList.add('show');
  document.getElementById('chatInput')?.focus();
}

function renderThread() {
  const me = state.session?.user?.id || 'guest';
  const tid = threadId(state.chatListingId, me);
  const rows = loadChats().filter(m => m.thread === tid);
  const box = document.getElementById('chatMessages');
  if (!rows.length) {
    box.innerHTML = '<p style="color:#66736b">No messages yet. Ask if the item is still available.</p>';
    return;
  }
  box.innerHTML = rows.map(m => `
    <div style="margin:8px 0;text-align:${m.sender === me ? 'right' : 'left'}">
      <div style="display:inline-block;max-width:80%;padding:8px 12px;border-radius:12px;background:${m.sender === me ? '#176b45' : '#eef3ec'};color:${m.sender === me ? '#fff' : '#17211b'}">
        ${escapeHtml(m.body)}
      </div>
      <div style="font-size:11px;color:#7a857d">${new Date(m.time).toLocaleString()}</div>
    </div>`).join('');
  box.scrollTop = box.scrollHeight;
}

async function sendChat() {
  const input = document.getElementById('chatInput');
  const body = input.value.trim();
  if (!body) return;
  const me = state.session?.user?.id || 'guest';
  const item = findItem(state.chatListingId);
  const msg = {
    thread: threadId(state.chatListingId, me),
    listingId: state.chatListingId,
    title: item?.title || '',
    seller: item?.seller || '',
    sender: me,
    body,
    time: new Date().toISOString()
  };
  const rows = loadChats();
  rows.push(msg);
  saveChats(rows);
  input.value = '';
  renderThread();

  const client = getClient();
  if (client && item?.cloudDbId) {
    const { error } = await client.from('messages').insert({
      listing_id: item.cloudDbId,
      buyer_id: me,
      sender_id: me,
      body
    });
    if (error) console.warn('Cloud chat unavailable:', error.message);
  }
}

export function bindChatUI() {
  document.getElementById('messagesBtn')?.addEventListener('click', () => {
    if (!state.session?.user) {
      window.marketHubAuth?.open();
      toast('Sign in to see your chats.');
      return;
    }
    const me = state.session.user.id;
    const rows = loadChats().filter(m => m.thread.endsWith(':' + me) || m.sender === me);
    const seen = new Set();
    const threads = [];
    for (let i = rows.length - 1; i >= 0; i--) {
      if (seen.has(rows[i].thread)) continue;
      seen.add(rows[i].thread);
      threads.push(rows[i]);
    }
    document.getElementById('chatTitle').textContent = 'Your chats';
    document.getElementById('chatSub').textContent = 'Tap a chat to continue';
    const box = document.getElementById('chatMessages');
    box.innerHTML = threads.length
      ? threads.map(t => `<button class="ghost" data-open-thread="${t.listingId}" style="width:100%;text-align:left;margin:6px 0"><b>${escapeHtml(t.title || 'Listing')}</b><br><span style="color:#66736b">${escapeHtml(t.body)}</span></button>`).join('')
      : '<p style="color:#66736b">No chats yet. Open a listing and tap Contact seller.</p>';
    document.getElementById('chatModal').classList.add('show');
  });
  document.getElementById('chatForm')?.addEventListener('submit', e => {
    e.preventDefault();
    sendChat();
  });
  document.getElementById('chatMessages')?.addEventListener('click', e => {
    const btn = e.target.closest('[data-open-thread]');
    if (btn) openChatForItem(Number(btn.dataset.openThread) || btn.dataset.openThread);
  });
  window.openChatForItem = openChatForItem;
}

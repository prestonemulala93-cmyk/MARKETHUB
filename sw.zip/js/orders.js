import { state, findItem, persistLocalOrders } from './state.js';
import { escapeHtml, money, toast } from './utils.js';
import * as cloud from './cloud.js';
import { getClient } from './auth.js';

export function setFulfilment(mode) {
  try {
    const val = mode === 'rider' ? 'Deliver it to me' : "I'll collect it / meet seller";
    const hidden = document.getElementById('fulfilmentValue');
    if (hidden) hidden.value = val;
    const collect = document.getElementById('fulfilCollect');
    const rider = document.getElementById('fulfilRider');
    if (collect) {
      collect.style.background = mode === 'collect' ? '#e3f5df' : '';
      collect.style.color = mode === 'collect' ? '#176b45' : '';
    }
    if (rider) {
      rider.style.background = mode === 'rider' ? '#e3f5df' : '';
      rider.style.color = mode === 'rider' ? '#176b45' : '';
    }
    toggleDropAddress();
  } catch (e) {
    console.warn('setFulfilment failed', e);
  }
}
window.setFulfilment = setFulfilment;

export function toggleDropAddress() {
  try {
    const delivery = document.getElementById('fulfilmentValue')?.value === 'Deliver it to me';
    const wrap = document.getElementById('dropAddressWrap');
    const addr = document.getElementById('dropAddress');
    if (wrap) wrap.style.display = delivery ? 'block' : 'none';
    if (addr) addr.required = delivery;
  } catch (e) {
    console.warn('toggleDropAddress failed', e);
  }
}

export function openCheckout(id, basketItems) {
  const x = findItem(id);
  if (!x) return;
  // Block ordering your own listing
  if (state.session?.user && x.seller) {
    const myShops = state.myCloudListings || [];
    const isMine = myShops.some(l => l.cloudDbId && l.cloudDbId === x.cloudDbId);
    if (isMine) {
      toast('You cannot order your own listing.');
      return;
    }
  }
  state.checkoutId = id;
  state.basketCheckout = basketItems || null;
  const summary = basketItems && basketItems.length > 1
    ? `<div style="background:#f2f6f0;border-radius:12px;padding:12px;margin-bottom:10px"><b>Basket (${basketItems.length} items)</b><br>${basketItems.map(i => escapeHtml(i.title)).join(', ')}</div>`
    : '';
  document.getElementById('checkoutItem').innerHTML = summary + `
    <div style="display:flex;gap:12px;align-items:center;background:#f2f6f0;border-radius:12px;padding:12px">
      <div style="font-size:42px">${x.emoji || '📦'}</div>
      <div><b>${escapeHtml(x.title)}</b>
        <div style="color:#176b45;font-weight:900;font-size:20px">${money(x.price)}</div>
        <small>Seller: ${escapeHtml(x.seller)}</small>
      </div>
    </div>`;
  document.getElementById('checkoutTotal').textContent =
    'Item total: ' + money(x.price) + ' (delivery fee, if any, agreed separately)';
  document.getElementById('detailModal').classList.remove('show');
  document.getElementById('cartModal')?.classList.remove('show');
  document.getElementById('checkoutModal').classList.add('show');
  setFulfilment('collect');
}

export async function openOrders() {
  await cloud.loadBuyerOrders();
  const box = document.getElementById('ordersList');
  const cloudRows = state.cloudOrders || [];
  const localRows = state.localOrders || [];

  if (!cloudRows.length && !localRows.length) {
    box.innerHTML =
      '<div class="empty"><div style="font-size:38px">📦</div><h3>No orders yet</h3><p>When you use Buy now and submit an order request, it will appear here.</p></div>';
  } else {
    let html = '';
    if (cloudRows.length) {
      html += '<h3 style="margin:0 0 8px">Your cloud orders</h3>';
      html += cloudRows
        .map(
          o => `<div style="border:1px solid #e1e8df;border-radius:12px;padding:14px;margin:10px 0">
          <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
            <b>${escapeHtml(o.item_title)}</b>
            <b style="color:#176b45">${money(o.price_zmw)}</b>
          </div>
          <p style="margin:6px 0;color:#637067;font-size:13px">
            ${escapeHtml(o.status || 'pending')} · ${o.created_at ? new Date(o.created_at).toLocaleString() : ''}
          </p>
          <div style="font-size:13px">
            Getting it: ${escapeHtml(o.fulfilment || 'Not specified')}<br>
            Payment: ${escapeHtml(o.payment_method || 'Not specified')}<br>
            Town: ${escapeHtml(o.buyer_town || 'Not specified')}
          </div>
          ${o.drop_address ? `<p style="font-size:13px">Drop-off: ${escapeHtml(o.drop_address)}</p>` : ''}
        </div>`
        )
        .join('');
    }
    if (localRows.length) {
      html += '<h3 style="margin:16px 0 8px">Local demo orders (this device)</h3>';
      html += localRows
        .map(
          (o, i) => `<div style="border:1px solid #e1e8df;border-radius:12px;padding:14px;margin:10px 0">
          <div style="display:flex;justify-content:space-between;gap:10px"><b>${escapeHtml(o.item)}</b><b style="color:#176b45">${money(o.price)}</b></div>
          <p style="margin:6px 0;color:#637067;font-size:13px">Demo #${localRows.length - i} · ${new Date(o.time).toLocaleString()}</p>
          <div style="font-size:13px">Getting it: ${escapeHtml(o.fulfilment || 'Not specified')}<br>Payment: ${escapeHtml(o.payment || 'Not specified')}</div>
          <p style="font-size:12px;color:#7b867e;margin-bottom:0">Saved on this device only.</p>
        </div>`
        )
        .join('');
    }
    box.innerHTML = html;
  }
  document.getElementById('ordersModal').classList.add('show');
}

export function bindOrdersUI(render) {
  document.getElementById('ordersBtn').onclick = openOrders;

  document.getElementById('checkoutForm').onsubmit = async e => {
    e.preventDefault();
    const x = findItem(state.checkoutId);
    if (!x) return;
    // Second guard against self-orders
    if (state.session?.user && x.cloudDbId) {
      const mine = (state.myCloudListings || []).some(l => l.cloudDbId === x.cloudDbId);
      if (mine) {
        toast('You cannot order your own listing.');
        return;
      }
    }

    const order = {
      item: x.title,
      price: x.price,
      buyer: document.getElementById('buyerName').value.trim(),
      phone: document.getElementById('buyerPhone').value.trim(),
      town: document.getElementById('buyerTown').value,
      fulfilment: document.getElementById('fulfilmentValue').value,
      address: document.getElementById('dropAddress').value.trim(),
      pin: document.getElementById('dropPin').value.trim(),
      payment: document.getElementById('paymentMethod').value,
      notes: document.getElementById('buyerNotes').value.trim(),
      time: new Date().toISOString(),
      listingCloudId: x.cloudDbId || null,
      shopId: x.shopId || null
    };

    let cloudOk = false;
    try {
      if (getClient() && x.cloudDbId) {
        const created = await cloud.createCloudOrder(order);
        cloudOk = true;
        toast('Order submitted to MarketHub · status: ' + (created.status || 'pending'));
        await cloud.loadBuyerOrders();
      }
    } catch (err) {
      console.warn('Cloud order failed, saving locally:', err.message || err);
      toast('Cloud order unavailable — saved on this device. (' + (err.message || 'check orders table / RLS') + ')');
    }

    if (!cloudOk) {
      state.localOrders.unshift(order);
      persistLocalOrders();
      if (!getClient() || !x.cloudDbId) {
        toast('Demo order request saved on this device — contact the seller to confirm.');
      }
    }

    document.getElementById('checkoutModal').classList.remove('show');
    e.target.reset();
    toggleDropAddress();
    document.getElementById('dropMapWrap').style.display = 'none';
    render();
    showDetailSafe(x.id);
  };

  const pinInput = document.getElementById('dropPin');
  pinInput?.addEventListener('input', () => {
    const v = pinInput.value.trim();
    const wrap = document.getElementById('dropMapWrap');
    if (!v) {
      wrap.style.display = 'none';
      return;
    }
    wrap.style.display = 'block';
    document.getElementById('dropMap').src = mapEmbedSafe(v);
    document.getElementById('dropMapLink').href = /^https?:\/\//i.test(v)
      ? v
      : 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(v);
  });

  window.toggleDropAddress = toggleDropAddress;
  window.setFulfilment = setFulfilment;
  window.buyNow = openCheckout;
}

function mapEmbedSafe(v) {
  return 'https://maps.google.com/maps?q=' + encodeURIComponent(v + ', Zambia') + '&output=embed';
}

function showDetailSafe(id) {
  import('./listings-ui.js').then(m => m.showDetail(id)).catch(() => {});
}
